package com.askmusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.askmusic.app.ui.AskMusicRoot
import com.askmusic.app.ui.AskMusicTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AskMusicApp.instance.player.connect()
        setContent {
            AskMusicTheme {
                AskMusicRoot()
            }
        }
    }
}
