package com.askmusic.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/** Favorit & riwayat putar, disimpan lokal di SharedPreferences (JSON). */
class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("askmusic_library", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val serializer = ListSerializer(Song.serializer())

    private val _favorites = MutableStateFlow(load(KEY_FAVORITES))
    val favorites: StateFlow<List<Song>> = _favorites.asStateFlow()

    private val _history = MutableStateFlow(load(KEY_HISTORY))
    val history: StateFlow<List<Song>> = _history.asStateFlow()

    private fun load(key: String): List<Song> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return runCatching { json.decodeFromString(serializer, raw) }.getOrDefault(emptyList())
    }

    private fun save(key: String, list: List<Song>) {
        prefs.edit().putString(key, json.encodeToString(serializer, list)).apply()
    }

    @Synchronized
    fun toggleFavorite(song: Song) {
        val current = _favorites.value
        val next =
            if (current.any { it.id == song.id }) {
                current.filterNot { it.id == song.id }
            } else {
                listOf(song) + current
            }
        _favorites.value = next
        save(KEY_FAVORITES, next)
    }

    @Synchronized
    fun addHistory(song: Song) {
        val next = (listOf(song) + _history.value.filterNot { it.id == song.id }).take(MAX_HISTORY)
        _history.value = next
        save(KEY_HISTORY, next)
    }

    @Synchronized
    fun clearHistory() {
        _history.value = emptyList()
        save(KEY_HISTORY, emptyList())
    }

    private companion object {
        const val KEY_FAVORITES = "favorites"
        const val KEY_HISTORY = "history"
        const val MAX_HISTORY = 100
    }
}
