package com.askmusic.app.data

import kotlinx.serialization.Serializable

/** Lagu yang bisa diputar (disimpan juga di Favorit / Riwayat). */
@Serializable
data class Song(
    val id: String,
    val title: String,
    val artist: String = "",
    val thumbnail: String? = null,
    val durationText: String? = null,
)

/** Item hasil pencarian / beranda: bisa lagu, album, playlist, mix, atau artis. */
data class Entry(
    val title: String,
    val subtitle: String = "",
    val thumbnail: String? = null,
    val videoId: String? = null,
    val browseId: String? = null,
    val playlistId: String? = null,
    val durationText: String? = null,
) {
    fun toSong(): Song? = videoId?.let { Song(it, title, subtitle, thumbnail, durationText) }
}

data class Shelf(val title: String, val entries: List<Entry>)

enum class SearchFilter(val label: String, val params: String) {
    SONG("Lagu", "EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D"),
    VIDEO("Video", "EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D"),
    ALBUM("Album", "EgWKAQIYAWoKEAkQChAFEAMQBA%3D%3D"),
    ARTIST("Artis", "EgWKAQIgAWoKEAkQChAFEAMQBA%3D%3D"),
}

sealed interface UiLoad<out T> {
    data object Idle : UiLoad<Nothing>
    data object Loading : UiLoad<Nothing>
    data class Data<T>(val value: T) : UiLoad<T>
    data class Error(val message: String) : UiLoad<Nothing>
}

private val SIZE_REGEX = Regex("=w\\d+-h\\d+")

/** Thumbnail googleusercontent bisa diminta ukuran lain lewat parameter =wXXX-hXXX. */
fun String.withSize(px: Int): String =
    if (SIZE_REGEX.containsMatchIn(this)) replace(SIZE_REGEX, "=w$px-h$px") else this
