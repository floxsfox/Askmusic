package com.askmusic.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.askmusic.app.AskMusicApp

@Composable
fun LibraryScreen(padding: PaddingValues) {
    val app = AskMusicApp.instance
    val favorites by app.library.favorites.collectAsState()
    val history by app.library.history.collectAsState()
    val playerState by app.player.state.collectAsState()
    var showFavorites by rememberSaveable { mutableStateOf(true) }
    val list = if (showFavorites) favorites else history

    Column(Modifier.fillMaxSize().padding(padding)) {
        Text(
            "Koleksi",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = showFavorites,
                onClick = { showFavorites = true },
                label = { Text("Favorit (${favorites.size})") },
            )
            FilterChip(
                selected = !showFavorites,
                onClick = { showFavorites = false },
                label = { Text("Riwayat (${history.size})") },
            )
        }

        if (list.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = { app.player.playSongs(list) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Text("Putar")
                }
                OutlinedButton(
                    onClick = { app.player.playSongs(list, startIndex = list.indices.random(), shuffle = true) },
                ) {
                    Icon(Icons.Filled.Shuffle, contentDescription = null)
                    Text("Acak")
                }
                if (!showFavorites) {
                    TextButton(onClick = { app.library.clearHistory() }) { Text("Hapus riwayat") }
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (list.isEmpty()) {
                item {
                    EmptyText(
                        if (showFavorites) {
                            "Belum ada favorit. Buka menu ⋮ pada lagu atau tombol ♥ di pemutar."
                        } else {
                            "Belum ada riwayat putar."
                        },
                    )
                }
            } else {
                itemsIndexed(list) { index, song ->
                    SongRow(
                        song = song,
                        isCurrent = playerState.current?.id == song.id,
                        onClick = { app.player.playSongs(list, index) },
                    )
                }
            }
        }
    }
}
