package com.askmusic.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.askmusic.app.AskMusicApp
import com.askmusic.app.data.Entry
import com.askmusic.app.data.Song
import com.askmusic.app.data.UiLoad
import kotlinx.coroutines.CancellationException

/** Detail album / playlist / artis: daftar lagu yang bisa langsung diputar. */
@Composable
fun CollectionScreen(entry: Entry, onBack: () -> Unit, padding: PaddingValues) {
    val app = AskMusicApp.instance
    val playerState by app.player.state.collectAsState()
    var state by remember(entry) { mutableStateOf<UiLoad<List<Song>>>(UiLoad.Loading) }
    var attempt by remember { mutableIntStateOf(0) }

    LaunchedEffect(entry, attempt) {
        state = UiLoad.Loading
        state =
            try {
                val songs = app.yt.collection(entry.browseId.orEmpty())
                if (songs.isEmpty()) UiLoad.Error("Tidak ada lagu yang bisa diputar di sini") else UiLoad.Data(songs)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error(e.message ?: "Gagal memuat")
            }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().padding(padding)) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(entry.thumbnail, Modifier.size(112.dp), corner = 12.dp, px = 360)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        entry.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (entry.subtitle.isNotBlank()) {
                        Text(
                            entry.subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            when (val s = state) {
                is UiLoad.Data -> {
                    val songs = s.value
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(onClick = { app.player.playSongs(songs) }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Text("Putar")
                        }
                        OutlinedButton(
                            onClick = { app.player.playSongs(songs, startIndex = songs.indices.random(), shuffle = true) },
                        ) {
                            Icon(Icons.Filled.Shuffle, contentDescription = null)
                            Text("Acak")
                        }
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        itemsIndexed(songs) { index, song ->
                            SongRow(
                                song = song,
                                isCurrent = playerState.current?.id == song.id,
                                onClick = { app.player.playSongs(songs, index) },
                            )
                        }
                    }
                }
                is UiLoad.Error -> ErrorBox(s.message, onRetry = { attempt++ })
                else -> LoadingBox()
            }
        }
    }
}
