package com.askmusic.app.data

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement

private const val SEP = " • "
private val DURATION_REGEX = Regex("""^\d{1,2}(:\d{2}){1,2}$""")
private val ARTIST_TYPES = setOf("MUSIC_PAGE_TYPE_ARTIST", "MUSIC_PAGE_TYPE_USER_CHANNEL")

private fun lastThumb(thumbs: JsonElement?): String? =
    (thumbs as? JsonArray)?.lastOrNull().at("url").text()

private fun runList(runs: JsonElement?): List<JsonElement> = (runs as? JsonArray).orEmpty()

/** Pecah runs "A • B • C" menjadi ["A", "B", "C"]. */
private fun groupTexts(runs: List<JsonElement>): List<String> {
    val groups = mutableListOf(StringBuilder())
    for (run in runs) {
        val t = run.at("text").text().orEmpty()
        if (t == SEP) groups.add(StringBuilder()) else groups.last().append(t)
    }
    return groups.map { it.toString().trim() }.filter { it.isNotEmpty() }
}

/** Nama artis = run yang menuju halaman artis (tidak tergantung bahasa). */
private fun artistNames(runs: List<JsonElement>): String =
    runs.filter { run ->
        val pageType =
            run.at(
                "navigationEndpoint",
                "browseEndpoint",
                "browseEndpointContextSupportedConfigs",
                "browseEndpointContextMusicConfig",
                "pageType",
            ).text()
        pageType != null && pageType in ARTIST_TYPES
    }.joinToString(", ") { it.at("text").text().orEmpty() }

/** musicResponsiveListItemRenderer: baris hasil pencarian / daftar lagu. */
internal fun parseListEntry(r: JsonElement): Entry? {
    val videoId = r.at("playlistItemData", "videoId").text()
    val browseId = r.at("navigationEndpoint", "browseEndpoint", "browseId").text()
    if (videoId == null && browseId == null) return null

    val cols = r.at("flexColumns") as? JsonArray ?: return null
    val title = cols.getOrNull(0).at("musicResponsiveListItemFlexColumnRenderer", "text").runsText()
    if (title.isBlank()) return null

    val subRuns = runList(cols.getOrNull(1).at("musicResponsiveListItemFlexColumnRenderer", "text", "runs"))
    val groups = groupTexts(subRuns)
    val artist = artistNames(subRuns)

    val fixedText =
        r.at("fixedColumns", 0, "musicResponsiveListItemFixedColumnRenderer", "text").runsText()
    val duration =
        fixedText.takeIf { DURATION_REGEX.matches(it) }
            ?: groups.lastOrNull()?.takeIf { DURATION_REGEX.matches(it) }

    val subtitle =
        if (videoId != null) {
            artist.ifBlank { groups.firstOrNull().orEmpty() }
        } else {
            groups.joinToString(SEP)
        }

    return Entry(
        title = title,
        subtitle = subtitle,
        thumbnail = lastThumb(r.at("thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails")),
        videoId = videoId,
        browseId = if (videoId == null) browseId else null,
        durationText = duration,
    )
}

/** musicTwoRowItemRenderer: kartu di carousel beranda. */
internal fun parseTwoRow(r: JsonElement): Entry? {
    val title = r.at("title").runsText()
    if (title.isBlank()) return null
    val subRuns = runList(r.at("subtitle", "runs"))
    val nav = r.at("navigationEndpoint")
    val videoId = nav.at("watchEndpoint", "videoId").text()
    val browseId = nav.at("browseEndpoint", "browseId").text()
    val playlistId = nav.at("watchPlaylistEndpoint", "playlistId").text()
    if (videoId == null && browseId == null && playlistId == null) return null

    val subtitleFull = r.at("subtitle").runsText()
    val subtitle =
        if (videoId != null) artistNames(subRuns).ifBlank { subtitleFull } else subtitleFull

    return Entry(
        title = title,
        subtitle = subtitle,
        thumbnail = lastThumb(r.at("thumbnailRenderer", "musicThumbnailRenderer", "thumbnail", "thumbnails")),
        videoId = videoId,
        browseId = if (videoId == null) browseId else null,
        playlistId = if (videoId == null && browseId == null) playlistId else null,
    )
}

/** playlistPanelVideoRenderer: item di "Up next" / radio. */
internal fun parsePanelSong(r: JsonElement): Song? {
    val id = r.at("videoId").text() ?: return null
    val title = r.at("title").runsText()
    if (title.isBlank()) return null
    val runs = runList(r.at("longBylineText", "runs"))
    val artist = artistNames(runs).ifBlank { groupTexts(runs).firstOrNull().orEmpty() }
    val duration = r.at("lengthText").runsText().takeIf { it.isNotBlank() }
    return Song(
        id = id,
        title = title,
        artist = artist,
        thumbnail = lastThumb(r.at("thumbnail", "thumbnails")),
        durationText = duration,
    )
}
