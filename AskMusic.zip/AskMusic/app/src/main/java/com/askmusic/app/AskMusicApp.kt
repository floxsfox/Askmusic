package com.askmusic.app

import android.app.Application
import com.askmusic.app.data.LibraryStore
import com.askmusic.app.data.YtMusic
import com.askmusic.app.playback.PlayerConnection

class AskMusicApp : Application() {
    lateinit var yt: YtMusic
        private set
    lateinit var library: LibraryStore
        private set
    lateinit var player: PlayerConnection
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        yt = YtMusic()
        library = LibraryStore(this)
        player = PlayerConnection(this, library, yt)
    }

    companion object {
        lateinit var instance: AskMusicApp
            private set
    }
}
