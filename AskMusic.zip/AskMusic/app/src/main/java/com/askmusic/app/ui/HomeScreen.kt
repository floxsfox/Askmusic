package com.askmusic.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.askmusic.app.AskMusicApp
import com.askmusic.app.data.Entry
import com.askmusic.app.data.Shelf
import com.askmusic.app.data.UiLoad
import kotlinx.coroutines.CancellationException

@Composable
fun HomeScreen(onEntryClick: (Entry) -> Unit, padding: PaddingValues) {
    val yt = AskMusicApp.instance.yt
    var state by remember { mutableStateOf<UiLoad<List<Shelf>>>(UiLoad.Loading) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload) {
        state = UiLoad.Loading
        state =
            try {
                val shelves = yt.home(force = reload > 0)
                if (shelves.isEmpty()) {
                    UiLoad.Error("Beranda kosong. Coba muat ulang.")
                } else {
                    UiLoad.Data(shelves)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error(e.message ?: "Gagal memuat beranda")
            }
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = padding) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Ask Music",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { reload++ }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Muat ulang")
                }
            }
        }
        when (val s = state) {
            is UiLoad.Data -> items(s.value) { shelf -> ShelfSection(shelf, onEntryClick) }
            is UiLoad.Error -> item { ErrorBox(s.message, onRetry = { reload++ }) }
            else -> item { LoadingBox() }
        }
    }
}

@Composable
private fun ShelfSection(shelf: Shelf, onEntryClick: (Entry) -> Unit) {
    Column(Modifier.padding(top = 16.dp)) {
        Text(
            shelf.title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(shelf.entries) { entry ->
                Column(
                    Modifier
                        .width(144.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onEntryClick(entry) },
                ) {
                    Artwork(entry.thumbnail, Modifier.size(144.dp), corner = 10.dp, px = 360)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        entry.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        entry.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
