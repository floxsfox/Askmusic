package com.askmusic.app.playback

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.mkv.MatroskaExtractor
import androidx.media3.extractor.mp4.FragmentedMp4Extractor
import androidx.media3.extractor.mp4.Mp4Extractor
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.askmusic.app.AskMusicApp
import com.askmusic.app.MainActivity
import com.askmusic.app.data.YtMusic
import com.metrolist.innertubex.extraction.StreamResolveException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.IOException

/**
 * Service pemutar musik: ExoPlayer + MediaSession (notifikasi, kontrol layar kunci, Bluetooth).
 * URL audio YouTube di-resolve secara lazy lewat [ResolvingDataSource] tepat sebelum diunduh.
 */
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var cache: SimpleCache? = null
    private val retried = HashSet<String>()

    override fun onCreate() {
        super.onCreate()
        val yt = (application as AskMusicApp).yt

        val simpleCache =
            SimpleCache(
                File(cacheDir, "audio"),
                LeastRecentlyUsedCacheEvictor(CACHE_BYTES),
                StandaloneDatabaseProvider(this),
            )
        cache = simpleCache

        val httpFactory =
            DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(20_000)

        val cacheFactory =
            CacheDataSource.Factory()
                .setCache(simpleCache)
                .setUpstreamDataSourceFactory(httpFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val dataSourceFactory: DataSource.Factory =
            ResolvingDataSource.Factory(cacheFactory) { dataSpec -> resolve(yt, simpleCache, dataSpec) }

        val extractorsFactory =
            ExtractorsFactory { arrayOf(MatroskaExtractor(), FragmentedMp4Extractor(), Mp4Extractor()) }

        val player =
            ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory))
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    true,
                )
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()

        player.addListener(
            object : Player.Listener {
                override fun onMediaItemTransition(
                    mediaItem: androidx.media3.common.MediaItem?,
                    reason: Int,
                ) {
                    retried.clear()
                }

                override fun onPlayerError(error: PlaybackException) {
                    val id = player.currentMediaItem?.mediaId
                    if (id != null && retried.add(id)) {
                        // URL kemungkinan kedaluwarsa / ditolak: buang cache URL lalu coba sekali lagi.
                        yt.invalidateStream(id)
                        player.prepare()
                    } else if (player.hasNextMediaItem()) {
                        player.seekToNextMediaItem()
                        player.prepare()
                        player.play()
                    }
                }
            },
        )

        val sessionActivity =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )

        mediaSession =
            MediaSession.Builder(this, player)
                .setSessionActivity(sessionActivity)
                .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        cache?.release()
        cache = null
        super.onDestroy()
    }

    private fun resolve(yt: YtMusic, cache: SimpleCache, dataSpec: DataSpec): DataSpec {
        val id = dataSpec.key ?: return dataSpec

        // Kalau bagian yang diminta sudah ada di cache disk, tidak perlu resolve URL (hemat kuota & bisa offline).
        val knownLength = ContentMetadata.getContentLength(cache.getContentMetadata(id))
        val requiredLength =
            when {
                dataSpec.length >= 0 -> dataSpec.length
                knownLength > 0 -> (knownLength - dataSpec.position).coerceAtLeast(1L)
                else -> PROBE_LENGTH
            }
        if (cache.isCached(id, dataSpec.position, requiredLength)) return dataSpec

        val stream =
            try {
                runBlocking(Dispatchers.IO) { yt.resolveStream(id) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                throw IOException(describe(e), e)
            }

        var spec = dataSpec.withUri(Uri.parse(stream.url)).withAdditionalHeaders(stream.headers)
        if (stream.bounded && stream.chunkBytes > 0L) {
            val length =
                if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
                    stream.chunkBytes
                } else {
                    minOf(dataSpec.length, stream.chunkBytes)
                }
            spec = spec.subrange(0L, length)
        }
        return spec
    }

    private fun describe(e: Exception): String =
        when {
            e is StreamResolveException && e.reason == StreamResolveException.Reason.NETWORK ->
                "Tidak ada koneksi internet"
            e is StreamResolveException && e.reason == StreamResolveException.Reason.AGE_RESTRICTED ->
                "Konten dibatasi usia"
            e is StreamResolveException && e.reason == StreamResolveException.Reason.UNAVAILABLE ->
                "Lagu tidak tersedia"
            e is java.net.UnknownHostException || e is java.net.ConnectException ->
                "Tidak ada koneksi internet"
            else -> e.message ?: "Gagal mengambil stream audio"
        }

    private companion object {
        const val CACHE_BYTES = 512L * 1024L * 1024L
        const val PROBE_LENGTH = 512L * 1024L
    }
}
