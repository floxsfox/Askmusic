package com.askmusic.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.askmusic.app.data.LibraryStore
import com.askmusic.app.data.Song
import com.askmusic.app.data.YtMusic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executor

data class PlayerUiState(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val index: Int = 0,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
)

/** Jembatan antara UI (Compose) dan [PlaybackService] lewat MediaController. */
class PlayerConnection(
    private val context: Context,
    private val library: LibraryStore,
    private val yt: YtMusic,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainExecutor = Executor { runnable -> Handler(Looper.getMainLooper()).post(runnable) }

    private var controller: MediaController? = null
    private var connecting = false
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private var lastErrorId: String? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val listener =
        object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                refresh(player)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                mediaItem?.let { library.addHistory(it.toSong()) }
            }

            override fun onPlayerError(error: PlaybackException) {
                val id = controller?.currentMediaItem?.mediaId
                // Error pertama untuk sebuah lagu dicoba ulang otomatis oleh service; tampilkan pesan kalau berulang.
                if (id != null && id == lastErrorId) {
                    val cause = error.cause?.message ?: error.message
                    _events.tryEmit("Gagal memutar: ${cause ?: "kesalahan tidak diketahui"}")
                }
                lastErrorId = id
            }
        }

    init {
        scope.launch {
            while (isActive) {
                delay(400)
                val c = controller ?: continue
                if (c.isPlaying) {
                    _state.update {
                        it.copy(
                            positionMs = c.currentPosition,
                            durationMs = c.duration.takeIf { d -> d != C.TIME_UNSET } ?: it.durationMs,
                        )
                    }
                }
            }
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                connecting = false
                try {
                    val c = future.get()
                    controller = c
                    c.addListener(listener)
                    refresh(c)
                    val callbacks = pending.toList()
                    pending.clear()
                    callbacks.forEach { it(c) }
                } catch (e: Exception) {
                    _events.tryEmit("Gagal terhubung ke pemutar: ${e.message}")
                }
            },
            mainExecutor,
        )
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) {
            block(c)
        } else {
            pending.add(block)
            connect()
        }
    }

    private fun refresh(player: Player) {
        val queue = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).toSong() }
        _state.value =
            PlayerUiState(
                current = player.currentMediaItem?.toSong(),
                isPlaying = player.isPlaying,
                isBuffering = player.playbackState == Player.STATE_BUFFERING,
                positionMs = player.currentPosition,
                durationMs = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
                shuffle = player.shuffleModeEnabled,
                repeatMode = player.repeatMode,
                queue = queue,
                index = player.currentMediaItemIndex,
                hasNext = player.hasNextMediaItem(),
                hasPrevious = player.hasPreviousMediaItem(),
            )
    }

    // ---------------------------------------------------------------- aksi

    fun playSongs(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
        if (songs.isEmpty()) return
        withController { c ->
            c.setMediaItems(songs.map { it.toMediaItem() }, startIndex.coerceIn(0, songs.lastIndex), 0L)
            c.shuffleModeEnabled = shuffle
            c.prepare()
            c.play()
        }
    }

    /** Putar satu lagu, lalu tambahkan lagu mirip (radio) ke antrean. */
    fun playRadio(seed: Song) {
        playSongs(listOf(seed))
        scope.launch {
            val more =
                runCatching { yt.upNext(seed.id, null) }
                    .getOrDefault(emptyList())
                    .filter { it.id != seed.id }
            if (more.isEmpty()) return@launch
            withController { c ->
                if (c.mediaItemCount == 1 && c.currentMediaItem?.mediaId == seed.id) {
                    c.addMediaItems(more.map { it.toMediaItem() })
                }
            }
        }
    }

    /** Putar sebuah mix / playlist radio YouTube Music berdasarkan playlistId. */
    fun playPlaylistId(playlistId: String) {
        scope.launch {
            val songs = runCatching { yt.upNext(null, playlistId) }.getOrDefault(emptyList())
            if (songs.isEmpty()) {
                _events.tryEmit("Playlist ini tidak bisa diputar")
            } else {
                playSongs(songs)
            }
        }
    }

    fun togglePlay() =
        withController { c ->
            if (c.isPlaying) {
                c.pause()
            } else {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }

    fun next() = withController { it.seekToNextMediaItem() }

    fun previous() = withController { it.seekToPreviousMediaItem() }

    fun seekTo(positionMs: Long) = withController { it.seekTo(positionMs) }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() =
        withController {
            it.repeatMode =
                when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
        }

    fun playQueueIndex(index: Int) =
        withController {
            it.seekToDefaultPosition(index)
            it.play()
        }

    fun removeFromQueue(index: Int) = withController { it.removeMediaItem(index) }

    fun addToQueue(song: Song) =
        withController { c ->
            if (c.mediaItemCount == 0) {
                playSongs(listOf(song))
            } else {
                c.addMediaItem(song.toMediaItem())
            }
        }

    fun playNext(song: Song) =
        withController { c ->
            if (c.mediaItemCount == 0) {
                playSongs(listOf(song))
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
            }
        }
}

private fun Song.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id)
        .setUri("https://music.youtube.com/watch?v=$id")
        .setCustomCacheKey(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setArtworkUri(thumbnail?.let { Uri.parse(it) })
                .build(),
        )
        .build()

private fun MediaItem.toSong(): Song =
    Song(
        id = mediaId,
        title = mediaMetadata.title?.toString().orEmpty(),
        artist = mediaMetadata.artist?.toString().orEmpty(),
        thumbnail = mediaMetadata.artworkUri?.toString(),
    )
