package com.askmusic.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors =
    darkColorScheme(
        primary = Color(0xFFB9A8FF),
        onPrimary = Color(0xFF2A1A7A),
        primaryContainer = Color(0xFF4130A6),
        onPrimaryContainer = Color(0xFFE5DEFF),
        secondary = Color(0xFFCAC3DC),
        background = Color(0xFF0F0F14),
        onBackground = Color(0xFFE6E1E9),
        surface = Color(0xFF14141B),
        onSurface = Color(0xFFE6E1E9),
        surfaceVariant = Color(0xFF2A2A36),
        onSurfaceVariant = Color(0xFFC9C5D0),
        surfaceContainer = Color(0xFF1A1A23),
        surfaceContainerHigh = Color(0xFF22222C),
        surfaceContainerHighest = Color(0xFF2B2B36),
        error = Color(0xFFFFB4AB),
    )

private val LightColors =
    lightColorScheme(
        primary = Color(0xFF5B3FE0),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFE5DEFF),
        onPrimaryContainer = Color(0xFF1A0A66),
        secondary = Color(0xFF5E5B71),
        background = Color(0xFFFCF8FF),
        onBackground = Color(0xFF1C1B20),
        surface = Color(0xFFFCF8FF),
        onSurface = Color(0xFF1C1B20),
        surfaceVariant = Color(0xFFE5E0EC),
        onSurfaceVariant = Color(0xFF48454F),
        surfaceContainer = Color(0xFFF0ECF4),
        surfaceContainerHigh = Color(0xFFEAE6EE),
        surfaceContainerHighest = Color(0xFFE5E1E9),
    )

@Composable
fun AskMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
