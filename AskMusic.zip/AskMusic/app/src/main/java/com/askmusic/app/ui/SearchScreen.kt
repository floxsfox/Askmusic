package com.askmusic.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.askmusic.app.AskMusicApp
import com.askmusic.app.data.Entry
import com.askmusic.app.data.SearchFilter
import com.askmusic.app.data.UiLoad
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(onEntryClick: (Entry) -> Unit, padding: PaddingValues) {
    val yt = AskMusicApp.instance.yt
    val focus = LocalFocusManager.current

    var query by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(SearchFilter.SONG) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var results by remember { mutableStateOf<UiLoad<List<Entry>>>(UiLoad.Idle) }
    var attempt by remember { mutableIntStateOf(0) }

    // Saran pencarian (debounce)
    LaunchedEffect(query, submitted) {
        val q = query.trim()
        if (q.isEmpty() || q == submitted) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(250)
        suggestions =
            try {
                yt.suggestions(q)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
    }

    // Hasil pencarian
    LaunchedEffect(submitted, filter, attempt) {
        if (submitted.isBlank()) {
            results = UiLoad.Idle
            return@LaunchedEffect
        }
        results = UiLoad.Loading
        results =
            try {
                UiLoad.Data(yt.search(submitted, filter))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error(e.message ?: "Pencarian gagal")
            }
    }

    Column(Modifier.fillMaxSize().padding(padding)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Cari lagu, artis, album") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            query = ""
                            submitted = ""
                        },
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions =
                KeyboardActions(
                    onSearch = {
                        submitted = query.trim()
                        focus.clearFocus()
                    },
                ),
        )

        if (submitted.isNotBlank()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SearchFilter.entries.forEach { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { filter = f },
                        label = { Text(f.label) },
                    )
                }
            }
        }

        val showSuggestions = suggestions.isNotEmpty() && query.trim() != submitted

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (showSuggestions) {
                items(suggestions) { suggestion ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                query = suggestion
                                submitted = suggestion
                                focus.clearFocus()
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Filled.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.width(16.dp))
                        Text(suggestion, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            } else {
                when (val r = results) {
                    is UiLoad.Data ->
                        if (r.value.isEmpty()) {
                            item { EmptyText("Tidak ada hasil") }
                        } else {
                            items(r.value) { entry ->
                                EntryRow(entry, onClick = { onEntryClick(entry) })
                            }
                        }
                    is UiLoad.Loading -> item { LoadingBox() }
                    is UiLoad.Error -> item { ErrorBox(r.message, onRetry = { attempt++ }) }
                    is UiLoad.Idle -> item { EmptyText("Ketik lalu tekan cari untuk mencari lagu dari YouTube Music") }
                }
            }
        }
    }
}
