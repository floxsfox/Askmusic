package com.askmusic.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.askmusic.app.AskMusicApp
import com.askmusic.app.data.Entry

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Beranda", Icons.Filled.Home),
    SEARCH("Cari", Icons.Filled.Search),
    LIBRARY("Koleksi", Icons.Filled.LibraryMusic),
}

@Composable
fun AskMusicRoot() {
    val app = AskMusicApp.instance
    val context = LocalContext.current
    val playerState by app.player.state.collectAsState()

    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Entry?>(null) }
    var expanded by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(Unit) {
        app.player.events.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }
    }

    val onEntryClick: (Entry) -> Unit = { entry ->
        val song = entry.toSong()
        val playlistId = entry.playlistId
        if (song != null) {
            app.player.playRadio(song)
        } else if (entry.browseId != null) {
            detail = entry
        } else if (playlistId != null) {
            app.player.playPlaylistId(playlistId)
        }
    }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = detail != null && !expanded) { detail = null }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    if (playerState.current != null) {
                        MiniPlayer(playerState, onClick = { expanded = true })
                    }
                    NavigationBar {
                        Tab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t && detail == null,
                                onClick = {
                                    tab = t
                                    detail = null
                                },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize()) {
                when (tab) {
                    Tab.HOME -> HomeScreen(onEntryClick, padding)
                    Tab.SEARCH -> SearchScreen(onEntryClick, padding)
                    Tab.LIBRARY -> LibraryScreen(padding)
                }
                val current = detail
                if (current != null) {
                    CollectionScreen(current, onBack = { detail = null }, padding = padding)
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            FullPlayer(playerState, onClose = { expanded = false })
        }
    }
}
