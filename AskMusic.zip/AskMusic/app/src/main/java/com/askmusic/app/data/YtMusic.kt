package com.askmusic.app.data

import com.metrolist.innertubex.InnerTube
import com.metrolist.innertubex.cipher.PlayerConfigRepository
import com.metrolist.innertubex.cipher.RemotePlayerConfigStore
import com.metrolist.innertubex.cipher.YouTubeCipherService
import com.metrolist.innertubex.extraction.AudioQuality
import com.metrolist.innertubex.extraction.ContentHints
import com.metrolist.innertubex.extraction.InnerTubeExtractor
import com.metrolist.innertubex.extraction.PlayerConfig
import com.metrolist.innertubex.extraction.YtConfigParser
import com.metrolist.innertubex.extraction.YtConfigParserImpl
import com.metrolist.innertubex.models.YouTubeClient
import com.metrolist.innertubex.models.YouTubeLocale
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.compression.ContentEncoding
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.header
import io.ktor.client.request.url
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Hasil resolve stream audio dari YouTube (URL bertanda tangan + header yang wajib dikirim). */
data class ResolvedStream(
    val url: String,
    val headers: Map<String, String>,
    val expiresAtMs: Long,
    val bounded: Boolean,
    val chunkBytes: Long,
)

/**
 * Klien YouTube Music (InnerTube, client WEB_REMIX) - API privat yang sama dengan yang dipakai
 * Metrolist. Request dibangun oleh library InnerTubeX; di sini kita hanya memanggil dan mem-parse.
 */
class YtMusic {
    private val webRemix = YouTubeClient.WEB_REMIX

    private val http: HttpClient by lazy {
        HttpClient(OkHttp) {
            expectSuccess = false
            install(ContentNegotiation) {
                json(
                    Json {
                        ignoreUnknownKeys = true
                        explicitNulls = false
                        encodeDefaults = true
                    },
                )
            }
            install(ContentEncoding) {
                gzip(0.9F)
                deflate(0.8F)
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 60_000
                connectTimeoutMillis = 30_000
                socketTimeoutMillis = 60_000
            }
            defaultRequest {
                url("https://music.youtube.com/youtubei/v1/")
                header("Accept", "application/json")
                header("Cache-Control", "no-cache")
            }
        }
    }

    private val innerTube: InnerTube by lazy {
        InnerTube(http).also {
            val locale = Locale.getDefault()
            it.locale =
                YouTubeLocale(
                    gl = locale.country.ifBlank { "US" },
                    hl = locale.language.ifBlank { "en" },
                )
        }
    }

    private val extractor: InnerTubeExtractor by lazy {
        val configStore =
            RemotePlayerConfigStore(
                httpClient = http,
                repository = PlayerConfigRepository.disabled(),
            )
        val cipher = YouTubeCipherService(http, configStore)
        val parser = YtConfigParserImpl(http, innerTube, configStore, cipherService = cipher)
        InnerTubeExtractor(
            configParser = parser.withEmbeddedFallback(),
            cipherService = cipher,
            innerTube = innerTube,
        )
    }

    private val sessionMutex = Mutex()

    @Volatile
    private var sessionReady = false

    private val streamCache = ConcurrentHashMap<String, ResolvedStream>()

    @Volatile
    private var homeCache: Pair<Long, List<Shelf>>? = null

    private suspend fun ensureSession() {
        if (sessionReady) return
        sessionMutex.withLock {
            if (sessionReady) return
            val visitorData = runCatching { innerTube.fetchFreshVisitorData() }.getOrNull()
            if (visitorData != null) {
                innerTube.visitorData = visitorData
                sessionReady = true
            }
        }
    }

    private suspend fun fetchJson(call: suspend () -> HttpResponse): JsonElement =
        withContext(Dispatchers.IO) { Json.parseToJsonElement(call().bodyAsText()) }

    // ---------------------------------------------------------------- pencarian & beranda

    suspend fun search(query: String, filter: SearchFilter): List<Entry> {
        ensureSession()
        val root = fetchJson { innerTube.search(webRemix, query = query, params = filter.params) }
        return root
            .findAll("musicResponsiveListItemRenderer")
            .mapNotNull { parseListEntry(it) }
            .distinctBy { it.videoId ?: it.browseId ?: it.title }
    }

    suspend fun suggestions(input: String): List<String> {
        ensureSession()
        val root = fetchJson { innerTube.getSearchSuggestions(webRemix, input) }
        return root
            .findAll("searchSuggestionRenderer")
            .map { it.at("suggestion").runsText() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    suspend fun home(force: Boolean = false): List<Shelf> {
        val cached = homeCache
        if (!force && cached != null && System.currentTimeMillis() - cached.first < HOME_CACHE_MS) {
            return cached.second
        }
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = "FEmusic_home") }
        val shelves =
            root.findAll("musicCarouselShelfRenderer").mapNotNull { shelf ->
                val title =
                    shelf.at("header", "musicCarouselShelfBasicHeaderRenderer", "title").runsText()
                val items =
                    (shelf.at("contents") as? JsonArray).orEmpty().mapNotNull { content ->
                        content.at("musicTwoRowItemRenderer")?.let { parseTwoRow(it) }
                            ?: content.at("musicResponsiveListItemRenderer")?.let { parseListEntry(it) }
                    }
                if (items.isEmpty()) null else Shelf(title.ifBlank { "Pilihan untukmu" }, items)
            }
        homeCache = System.currentTimeMillis() to shelves
        return shelves
    }

    /** Isi album / playlist / halaman artis: semua lagu yang ditemukan di halaman itu. */
    suspend fun collection(browseId: String): List<Song> {
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = browseId) }
        val header = root.findAll("musicResponsiveHeaderRenderer").firstOrNull()
        val headerArtist = header.at("straplineTextOne").runsText()
        val headerThumb =
            (header.at("thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails") as? JsonArray)
                ?.lastOrNull()
                .at("url")
                .text()
        return root
            .findAll("musicResponsiveListItemRenderer")
            .mapNotNull { parseListEntry(it)?.toSong() }
            .distinctBy { it.id }
            .map { song ->
                song.copy(
                    artist = song.artist.ifBlank { headerArtist },
                    thumbnail = song.thumbnail ?: headerThumb,
                )
            }
    }

    /** "Up next" / radio: lagu mirip dari sebuah lagu, atau isi sebuah mix (playlistId). */
    suspend fun upNext(videoId: String?, playlistId: String?): List<Song> {
        ensureSession()
        val root =
            fetchJson {
                innerTube.next(
                    webRemix,
                    videoId = videoId,
                    playlistId = playlistId ?: videoId?.let { "RDAMVM$it" },
                    params = if (playlistId == null) "wAEB" else null,
                )
            }
        return root
            .findAll("playlistPanelVideoRenderer")
            .mapNotNull { parsePanelSong(it) }
            .distinctBy { it.id }
    }

    // ---------------------------------------------------------------- stream audio

    suspend fun resolveStream(videoId: String, forceRefresh: Boolean = false): ResolvedStream {
        if (!forceRefresh) {
            val cached = streamCache[videoId]
            if (cached != null && cached.expiresAtMs - 60_000L > System.currentTimeMillis()) return cached
        }
        val resolved =
            withContext(Dispatchers.IO) {
                ensureSession()
                val hints =
                    ContentHints(wantVideo = false).withStreamCapabilities(
                        allowHls = false,
                        allowSabr = false,
                        allowBoundedRange = true,
                    )
                val stream =
                    extractor.extract(
                        videoId = videoId,
                        hints = hints,
                        audioQuality = AudioQuality.HIGH,
                    ) ?: throw IOException("Stream audio tidak ditemukan")
                if (stream.sabrBootstrap != null) throw IOException("Stream SABR belum didukung")
                ResolvedStream(
                    url = stream.audioUrl,
                    headers = stream.headers,
                    expiresAtMs =
                        stream.expiresAt?.toEpochMilliseconds()
                            ?: (System.currentTimeMillis() + DEFAULT_STREAM_TTL_MS),
                    bounded = stream.requireBoundedRange || stream.useRangeChunks,
                    chunkBytes = stream.rangeChunkSizeBytes,
                )
            }
        streamCache[videoId] = resolved
        return resolved
    }

    fun invalidateStream(videoId: String) {
        streamCache.remove(videoId)
    }

    private companion object {
        const val HOME_CACHE_MS = 5 * 60_000L
        const val DEFAULT_STREAM_TTL_MS = 5 * 60_000L
    }
}

/** Kalau config halaman watch gagal di-parse, coba config embed (sama seperti yang dilakukan Metrolist). */
private fun YtConfigParser.withEmbeddedFallback(): YtConfigParser {
    val delegate = this
    return object : YtConfigParser by delegate {
        override suspend fun fetchConfig(
            videoId: String,
            useLoginCookies: Boolean,
        ): PlayerConfig =
            try {
                delegate.fetchConfig(videoId, useLoginCookies)
            } catch (_: IllegalStateException) {
                delegate.fetchEmbeddedConfig(videoId, useLoginCookies = false)
            }
    }
}
