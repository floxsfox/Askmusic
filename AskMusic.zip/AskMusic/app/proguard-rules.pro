# Minify dimatikan di build.gradle.kts. Aturan ini hanya dipakai kalau kamu menyalakan isMinifyEnabled.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keep,includedescriptorclasses class com.askmusic.app.**$$serializer { *; }
-keepclassmembers class com.askmusic.app.** { *** Companion; }
-keepclasseswithmembers class com.askmusic.app.** { kotlinx.serialization.KSerializer serializer(...); }
-keep class com.metrolist.innertubex.** { *; }
-keep class io.ktor.** { *; }
-dontwarn **
