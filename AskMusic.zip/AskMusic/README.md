# Ask Music

Aplikasi musik Android (Kotlin + Jetpack Compose) yang memutar musik dari **YouTube Music**,
dengan cara yang sama seperti Metrolist: lewat API privat **InnerTube** (client `WEB_REMIX`) memakai
library [InnerTubeX](https://github.com/MetrolistGroup/innertubex) (JitPack).

## Fitur

- Beranda (carousel rekomendasi YouTube Music), pencarian (Lagu / Video / Album / Artis) + saran pencarian
- Detail album / playlist / artis, radio otomatis ("Up next") saat memutar sebuah lagu
- Pemutar penuh: seek, acak, ulangi, antrean (hapus / lompat), favorit
- Putar di latar belakang + notifikasi media + kontrol layar kunci / Bluetooth (Media3 `MediaSessionService`)
- Cache audio 512 MB di disk, favorit & riwayat tersimpan lokal

## Build lewat GitHub Actions

1. Buat repo GitHub baru, lalu upload **seluruh isi folder ini** (termasuk `.github/`, `gradle/`, dan `gradlew`).
2. Buka tab **Actions**. Workflow *Build Ask Music APK* jalan otomatis setiap push ke `main`/`master`
   (atau jalankan manual lewat **Run workflow**).
3. Setelah selesai (sekitar 5-10 menit untuk build pertama), buka run-nya, lalu unduh artifact **AskMusic-APK**:
   - `AskMusic-release.apk` -> versi rilis (id `com.askmusic.app`)
   - `AskMusic-debug.apk` -> versi debug (id `com.askmusic.app.debug`, bisa dipasang berdampingan)
4. Mau APK otomatis masuk ke halaman **Releases**? Push tag, mis. `git tag v1.0.0 && git push origin v1.0.0`.

### Keystore sendiri (opsional)

Tanpa keystore, APK rilis ditandatangani dengan debug key (tetap bisa di-install, tapi bukan untuk Play Store).
Untuk keystore sendiri, tambahkan 4 secret di repo: `KEYSTORE_BASE64` (isi file keystore yang di-base64),
`KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

### Build di komputer sendiri

JDK 21 + Android SDK, lalu `./gradlew assembleDebug`. APK ada di `app/build/outputs/apk/debug/`.

## Struktur kode

```
app/src/main/java/com/askmusic/app/
  AskMusicApp.kt, MainActivity.kt
  data/      YtMusic.kt (search/home/browse/next/stream), Parsers.kt, JsonUtils.kt, Models.kt, LibraryStore.kt
  playback/  PlaybackService.kt (ExoPlayer + cache + resolve URL), PlayerConnection.kt (jembatan ke UI)
  ui/        Theme, Home/Search/Library/Collection screens, MiniPlayer + FullPlayer, AskMusicRoot
```

Cara kerja singkat: `YtMusic` memanggil endpoint InnerTube (`search`, `browse`, `next`) lalu mem-parse JSON-nya
dengan pencarian key rekursif (tahan terhadap perubahan layout). Untuk memutar, `PlaybackService` memanggil
`InnerTubeExtractor.extract()` tepat sebelum audio diunduh; library itu yang memilih client YouTube, mengurus
deobfuscation signature, dan mengembalikan URL audio + header yang wajib dikirim.

## Catatan penting

- **API tidak resmi.** YouTube Music tidak punya API publik. InnerTube bisa berubah kapan saja; kalau pemutaran
  mendadak gagal, biasanya cukup menaikkan `innertubex` di `gradle/libs.versions.toml` ke versi terbaru
  (lihat <https://github.com/MetrolistGroup/innertubex>). Pemakaiannya juga bisa melanggar ketentuan layanan
  YouTube, jadi pakai untuk keperluan pribadi dan atas tanggung jawab sendiri.
- **Lisensi GPL-3.0.** InnerTubeX berlisensi GPL-3.0, jadi aplikasi ini (kalau dibagikan) juga harus GPL-3.0 dan
  menyertakan kode sumbernya. File `LICENSE` sudah disertakan.
- Belum ada PO-token (BotGuard). Kalau suatu saat YouTube mewajibkannya untuk semua client, sebagian lagu bisa gagal
  diputar; Metrolist mengatasinya dengan WebView, itu bisa ditambahkan belakangan.
- `isMinifyEnabled` sengaja `false` supaya library (ktor, serialization, innertubex) aman dari R8.
