pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // InnerTubeX (library YouTube Music yang dipakai Metrolist) + QuackJS ada di JitPack
        maven { setUrl("https://jitpack.io") }
    }
}

rootProject.name = "AskMusic"
include(":app")
